ENG:

Use the Python: 3.13 or higher and Install Pygame in command prompt:

[pip install pygame] <- Ignoring []

How to Play:


- Press the right key to move the player right;
- Press the left key to move the player left;

Compiling:

Use PyInstaller Package:

[pip install pyinstaller] <- Ignoring []

WARNING: The compiler python file to executable file that contains a viruses or potentially unwanted softwares that my PC is
getting destroyed from me. So, don't ask me why. If executable is found like as threat try disabling antivirus

Then compile the py to exe using command prompt:

[pyinstaller -F -w -i icon.ico main.py] <- Ignoring []

Then go to 'dist' folder and click the main.exe in the right mouse button and press 'Cut' or press 'Ctrl + X' on the keyboard.
Then click the right mouse button and click on: 'Rename'. And rename to 'Single Pong' title.

UKR:

Використовуйте Python: 3.13 або вище та встановіть Pygame в командному рядку:

[pip install pygame] <- Ігнорування []

Як грати:

- Натисніть праву клавішу, щоб перемістити гравця праворуч;

- Натисніть ліву клавішу, щоб перемістити гравця ліворуч;

Компіляція:

Використовуйте пакет PyInstaller:

[pip install pyinstaller] <- Ігнорування []

ПОПЕРЕДЖЕННЯ: Файл компілятора python перетворюється на виконуваний файл, який містить віруси або потенційно небажане програмне забезпечення, яке знищує мій ПК. Тож не питайте мене чому. Якщо виконуваний файл виявлено як загрозу, спробуйте вимкнути антивірус.

Потім скомпілюйте py в exe за допомогою командного рядка:

[pyinstaller -F -w -i icon.ico main.py] <- Ігнорування []

Потім перейдіть до папки 'dist' та клацніть main.exe правою кнопкою миші та натисніть 'Вирізати' або натисніть 'Ctrl + X' на клавіатурі.

Потім клацніть правою кнопкою миші та виберіть: «Перейменувати». І перейменуйте на назву «Single Pong».

JAP:

Python 3.13 以上を使用し、コマンドプロンプトで Pygame をインストールします。

[pip install pygame] <- [] は無視

遊び方:

- 右キーを押すとプレイヤーが右に移動します。
- 左キーを押すとプレイヤーが左に移動します。

コンパイル:

PyInstaller パッケージを使用します。

[pip install pyinstaller] <- [] は無視

警告: コンパイラの Python ファイルは、ウイルスや潜在的に不要なソフトウェアを含む実行ファイルに変換されます。PC が破壊されそうです。理由を聞かないでください。実行ファイルが脅威のように検出された場合は、ウイルス対策ソフトを無効にしてみてください。

コマンドプロンプトを使ってpyファイルをexeファイルにコンパイルします。

[pyinstaller -F -w -i icon.ico main.py] <- [] を無視

次に、「dist」フォルダに移動し、main.exeファイルを右クリックして「切り取り」を選択するか、キーボードでCtrl + Xを押します。
次に、マウスの右ボタンをクリックして「名前の変更」をクリックします。そして、「Single Pong」というタイトルに名前を変更します。